﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DIM_EXAM
{
    public partial class Form1 : Form
    {
        string CW;
        public Form1()
        {
            InitializeComponent();
        }

        public object CodeWork { get; private set; }

        private void Calculate_Click(object sender, EventArgs e)
        {
           
            using (SqlConnection conn = new SqlConnection(@"Data Source=WINDOWS-TTPP01P\SQLEXPRESS;Initial Catalog=SIGNIN_WINFORM;Integrated Security=TrueData Source=WINDOWS-TTPP01P\SQLEXPRESS;Initial Catalog=DIM_EXAM;Integrated Security=True"))
            {
                CW = Codework.Text;
                string insertStu = "Select Stu_Id  from Student where CodeWork='" + CW + "'";
                SqlCommand InsertCode = new SqlCommand(insertStu, conn);
                conn.Open();
                var result1 = InsertCode.ExecuteScalar();
               // MessageBox.Show(result1.ToString());
                using (SqlConnection conm = new SqlConnection(@"Data Source=WINDOWS-TTPP01P\SQLEXPRESS;Initial Catalog=SIGNIN_WINFORM;Integrated Security=TrueData Source=WINDOWS-TTPP01P\SQLEXPRESS;Initial Catalog=DIM_EXAM;Integrated Security=True"))
                {
                    string Det_sub = "Select T_Sub1, F_Sub1 ,T_Sub2, F_Sub2,T_Sub3, F_Sub3,T_Sub4, F_Sub4,T_Sub5, F_Sub5 from StudentResultDetails where  Stu_Id= " + result1.ToString() + "";
                    conm.Open();
                    SqlCommand Com_SD = new SqlCommand(Det_sub, conm);
                    var solution = Com_SD.ExecuteReader();
                    int f1 = 0;
                    var f2 = 0;
                    var f3 = 0;
                    var f4 = 0;
                    var f5 =0;
                    var f6 = 0;
                    var f7 = 0;
                    var f8 =0 ;
                    var f9 =0 ;
                    var f10 =0;

                    while (solution.Read())
                    {

                        f1 = (int)solution["T_Sub1"];
                        f2 = (int)solution["F_Sub1"];
                        f3 = (int)solution["T_Sub2"];
                        f4 = (int)solution["F_Sub2"];
                        f5 = (int)solution["T_Sub3"];
                        f6 = (int)solution["F_Sub3"];
                        f7 = (int)solution["T_Sub4"];
                        f8 = (int)solution["F_Sub4"];
                        f9 = (int)solution["T_Sub5"];
                        f10 = (int)solution["F_Sub5"];
                    }
                     conm.Close();
                    int totalscore = (f1 + f3)*8 + (f5 + f7 + f9) * 4 - (f2 + f4)/8 +( f6 + f8) / 4;
                    result.Text = totalscore.ToString();


                        }
             
            }
        }
        public class Student
        {
            public int Stu_Id { get; set; }
            public string Name { get; set; }
            public string LastName { get; set; }
            public string CodeWork { get; set; }
            public string Section { get; set; }
        }
        public class StudentResultdetails
        {
            public int ResultId { get; set; }
            public int  Stu_Id  {get;set;}
            public int T_Sub1 { get; set; }
            public int T_Sub2 { get; set; }
            public int T_Sub3 { get; set; }
            public int T_Sub4 { get; set; }
            public int T_Sub5 { get; set; }
            public int F_Sub1 { get; set; }
            public int F_Sub2 { get; set; }
            public int F_Sub3 { get; set; }
            public int F_Sub4 { get; set; }
            public int F_Sub5 { get; set; }
        }

    }
}
